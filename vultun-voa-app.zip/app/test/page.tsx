import TestSupabase from '../test-supabase';

export default function TestPage() {
  return <TestSupabase />;
} 