'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';

export default function AuthCallbackPage() {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [isResending, setIsResending] = useState(false);
  const [email, setEmail] = useState<string | null>(null);

  useEffect(() => {
    // Try to get email from URL if present
    const params = new URLSearchParams(window.location.search);
    const emailParam = params.get('email');
    if (emailParam) {
      setEmail(emailParam);
    }
  }, []);

  const handleResendVerification = async () => {
    if (!email) {
      setError('Please enter your email address');
      return;
    }

    try {
      setIsResending(true);
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: email.trim().toLowerCase(),
        options: {
          emailRedirectTo: `${window.location.origin}/auth/callback`
        }
      });

      if (error) {
        if (error.message.includes('Email rate limit exceeded')) {
          setError('Please wait a few minutes before requesting another verification email.');
        } else if (error.message.includes('Email address not authorized')) {
          setError('This email address is not authorized. Please contact support or use an authorized email.');
        } else {
          throw error;
        }
        return;
      }

      setError('A new verification link has been sent to your email. Please check your inbox and spam folder.');
    } catch (err: any) {
      console.error('Error resending verification:', err);
      setError(err.message || 'Failed to resend verification email. Please try again.');
    } finally {
      setIsResending(false);
    }
  };

  useEffect(() => {
    const handleEmailConfirmation = async () => {
      try {
        // Get the hash fragment from the URL
        const hashParams = new URLSearchParams(window.location.hash.substring(1));
        const error = hashParams.get('error_description');
        
        if (error) {
          console.error('Error in hash params:', error);
          setError(error);
          return;
        }

        // Get the session after email verification
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();

        if (sessionError) {
          console.error('Error getting session:', sessionError);
          setError('Failed to verify email. Please try again.');
          return;
        }

        if (session?.user) {
          // Check if customer record already exists
          const { data: existingCustomer, error: customerCheckError } = await supabase
            .from('customers')
            .select('id')
            .eq('user_id', session.user.id)
            .single();

          if (!existingCustomer) {
            try {
              // Create customer record if it doesn't exist
              const { error: customerError } = await supabase
                .from('customers')
                .insert({
                  user_id: session.user.id,
                  email: session.user.email,
                  full_name: session.user.user_metadata?.full_name || ''
                })
                .single();

              if (customerError) {
                console.error('Error creating customer:', customerError);
                if (!customerError.message.includes('unique constraint')) {
                  setError('Failed to create customer profile. Please contact support.');
                  return;
                }
              }
            } catch (err) {
              console.error('Error in customer creation:', err);
              setError('Failed to complete signup. Please contact support.');
              return;
            }
          }

          router.push('/dashboard?message=' + encodeURIComponent('Email verified successfully. Welcome!'));
        } else {
          console.error('No session found after verification');
          setError('Verification successful but login required.');
        }
      } catch (err) {
        console.error('Unexpected error during verification:', err);
        setError('An unexpected error occurred');
      }
    };

    handleEmailConfirmation();
  }, [router]);

  if (error?.includes('invalid or has expired')) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8">
          <div>
            <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
              Verification Link Expired
            </h2>
            <p className="mt-2 text-center text-sm text-gray-600">
              The verification link has expired. Please enter your email to receive a new link.
            </p>
          </div>
          {error && error !== 'Email link is invalid or has expired' && (
            <div className="rounded-md bg-red-50 p-4">
              <div className="text-sm text-red-700">{error}</div>
            </div>
          )}
          <div className="mt-8 space-y-6">
            <div className="rounded-md shadow-sm -space-y-px">
              <div>
                <input
                  type="email"
                  required
                  className="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                  placeholder="Email address"
                  value={email || ''}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>

            <div>
              <button
                onClick={handleResendVerification}
                disabled={isResending}
                className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                {isResending ? 'Sending...' : 'Resend Verification Email'}
              </button>
            </div>
          </div>
          <div className="text-center">
            <a
              href="/login"
              className="font-medium text-indigo-600 hover:text-indigo-500"
            >
              Return to Login
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h2 className="text-2xl font-semibold mb-4">Verifying your email...</h2>
        <p>Please wait while we confirm your email address.</p>
        {error && (
          <div className="mt-4 text-red-600">
            {error}
          </div>
        )}
      </div>
    </div>
  );
} 