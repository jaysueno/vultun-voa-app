'use client';

import { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabaseClient';
import { useRouter } from 'next/navigation';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  isSigningUp: boolean;
  isSigningIn: boolean;
  signUp: (email: string, password: string, fullName: string) => Promise<{ success: boolean; message?: string }>;
  signIn: (email: string, password: string) => Promise<{ success: boolean; message?: string }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSigningUp, setIsSigningUp] = useState(false);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const router = useRouter();

  useEffect(() => {
    // Check active sessions and sets the user
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    });

    // Listen for changes on auth state (signed in, signed out, etc.)
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const signUp = async (email: string, password: string, fullName: string): Promise<{ success: boolean; message?: string }> => {
    try {
      setIsSigningUp(true);
      const cleanEmail = email.trim().toLowerCase();

      // Check if user already exists - using a simpler query
      const { count, error: checkError } = await supabase
        .from('customers')
        .select('*', { count: 'exact', head: true })
        .eq('email', cleanEmail);

      if (checkError) {
        console.error('Error checking existing user:', checkError);
      } else if (count && count > 0) {
        return {
          success: false,
          message: 'An account with this email already exists. Please sign in instead.',
        };
      }

      console.log('Starting signup process...'); // Debug log

      // Create auth user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: cleanEmail,
        password,
        options: {
          data: {
            full_name: fullName.trim(),
            pending_customer: true // Flag to indicate we need to create customer record after verification
          },
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        },
      });

      console.log('Auth signup response:', { authData, authError }); // Debug log

      if (authError) {
        if (authError.message.includes('User already registered')) {
          return {
            success: false,
            message: 'An account with this email already exists. Please check your inbox for the verification email or try signing in.',
          };
        }
        console.error('Auth signup error:', authError);
        return {
          success: false,
          message: authError.message,
        };
      }

      if (!authData.user) {
        return {
          success: false,
          message: 'Signup failed. Please try again.',
        };
      }

      return {
        success: true,
        message: 'Account created successfully. Please check your email to verify your account. Note: The verification email may take a few minutes to arrive.',
      };

    } catch (error: any) {
      console.error('Signup process error:', error);
      return {
        success: false,
        message: error.message || 'An unexpected error occurred during signup.',
      };
    } finally {
      setIsSigningUp(false);
    }
  };

  const signIn = async (email: string, password: string): Promise<{ success: boolean; message?: string }> => {
    try {
      setIsSigningIn(true);
      const cleanEmail = email.trim().toLowerCase();
      
      // Check if user exists
      const { data: userData } = await supabase
        .from('customers')
        .select('email')
        .eq('email', cleanEmail)
        .single();

      if (!userData) {
        return {
          success: false,
          message: 'No account found with this email. Please sign up first.',
        };
      }

      const { data, error } = await supabase.auth.signInWithPassword({
        email: cleanEmail,
        password,
      });

      if (error) {
        if (error.message.includes('Email not confirmed')) {
          return {
            success: false,
            message: 'Please verify your email before signing in.',
          };
        }
        throw error;
      }

      if (data?.user) {
        router.refresh();
        router.push('/dashboard');
        return {
          success: true,
        };
      }

      return {
        success: false,
        message: 'Invalid credentials',
      };
    } catch (error: any) {
      console.error('Sign in error:', error);
      return {
        success: false,
        message: error.message || 'An error occurred during sign in.',
      };
    } finally {
      setIsSigningIn(false);
    }
  };

  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      router.refresh();
      router.push('/login');
    } catch (error: any) {
      console.error('Sign out error:', error);
      throw error;
    }
  };

  const value = {
    user,
    session,
    loading,
    isSigningUp,
    isSigningIn,
    signUp,
    signIn,
    signOut,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
} 