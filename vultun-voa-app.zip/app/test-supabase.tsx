'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

export default function TestSupabase() {
  const [status, setStatus] = useState<{
    connection: string;
    auth: string;
    database: string;
  }>({
    connection: 'Testing...',
    auth: 'Testing...',
    database: 'Testing...',
  });

  useEffect(() => {
    async function testConnection() {
      // Test 1: Basic Connection
      try {
        const { data, error } = await supabase.from('profiles').select('count');
        console.log('Connection test:', { data, error });
        setStatus(prev => ({
          ...prev,
          connection: error ? `Error: ${error.message}` : 'Connected successfully',
        }));
      } catch (e) {
        console.error('Connection error:', e);
        setStatus(prev => ({
          ...prev,
          connection: `Error: ${e.message}`,
        }));
      }

      // Test 2: Auth Configuration
      try {
        const { data, error } = await supabase.auth.getSession();
        console.log('Auth test:', { data, error });
        setStatus(prev => ({
          ...prev,
          auth: error ? `Error: ${error.message}` : 'Auth configured correctly',
        }));
      } catch (e) {
        console.error('Auth error:', e);
        setStatus(prev => ({
          ...prev,
          auth: `Error: ${e.message}`,
        }));
      }

      // Test 3: Database Access
      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .limit(1);
        console.log('Database test:', { data, error });
        setStatus(prev => ({
          ...prev,
          database: error ? `Error: ${error.message}` : 'Database access working',
        }));
      } catch (e) {
        console.error('Database error:', e);
        setStatus(prev => ({
          ...prev,
          database: `Error: ${e.message}`,
        }));
      }
    }

    testConnection();
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="max-w-md w-full space-y-8 p-6 bg-white rounded-lg shadow-md">
        <h2 className="text-2xl font-bold text-center">Supabase Connection Test</h2>
        <div className="space-y-4">
          <div>
            <h3 className="font-medium">Basic Connection:</h3>
            <p className={status.connection.includes('Error') ? 'text-red-600' : 'text-green-600'}>
              {status.connection}
            </p>
          </div>
          <div>
            <h3 className="font-medium">Auth Configuration:</h3>
            <p className={status.auth.includes('Error') ? 'text-red-600' : 'text-green-600'}>
              {status.auth}
            </p>
          </div>
          <div>
            <h3 className="font-medium">Database Access:</h3>
            <p className={status.database.includes('Error') ? 'text-red-600' : 'text-green-600'}>
              {status.database}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
} 