'use client';

import Login from '../../components/(auth)/Login';

export default function LoginPage() {
  return <Login />;
} 