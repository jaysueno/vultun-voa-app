'use client';

import { useAuth } from '@/app/context/AuthContext';

export default function DashboardPage() {
  const { user } = useAuth();

  return (
    <div className="space-y-6">
      <div className="bg-white shadow sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">
            Welcome back, {user?.user_metadata?.full_name || 'Guest'}!
          </h3>
          <div className="mt-2 max-w-xl text-sm text-gray-500">
            <p>
              This is your personal dashboard where you can manage your bookings and view your calendar.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <div className="bg-white overflow-hidden shadow sm:rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Quick Actions
            </h3>
            <div className="mt-5">
              <ul className="divide-y divide-gray-200">
                <li className="py-4">
                  <a
                    href="/dashboard/calendar"
                    className="text-indigo-600 hover:text-indigo-900"
                  >
                    View Calendar →
                  </a>
                </li>
                <li className="py-4">
                  <a
                    href="/dashboard/bookings"
                    className="text-indigo-600 hover:text-indigo-900"
                  >
                    Manage Bookings →
                  </a>
                </li>
                <li className="py-4">
                  <a
                    href="/dashboard/profile"
                    className="text-indigo-600 hover:text-indigo-900"
                  >
                    Update Profile →
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow sm:rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Account Information
            </h3>
            <div className="mt-5">
              <dl className="grid grid-cols-1 gap-5">
                <div>
                  <dt className="text-sm font-medium text-gray-500">Email</dt>
                  <dd className="mt-1 text-sm text-gray-900">{user?.email}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Name</dt>
                  <dd className="mt-1 text-sm text-gray-900">
                    {user?.user_metadata?.full_name || 'Not set'}
                  </dd>
                </div>
              </dl>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
} 