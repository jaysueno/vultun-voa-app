-- Drop existing customers table if it exists
DROP TABLE IF EXISTS public.customers;

-- Create function to calculate age
CREATE OR REPLACE FUNCTION calculate_age(birthdate DATE)
RETURNS INTEGER AS $$
BEGIN
    RETURN date_part('year', age(CURRENT_DATE, birthdate))::INTEGER;
END;
$$ LANGUAGE plpgsql;

-- Create function to generate customer ID
CREATE OR REPLACE FUNCTION generate_customer_id()
RETURNS TRIGGER AS $$
BEGIN
    NEW.customer_id := 'CUST-' || 
        EXTRACT(YEAR FROM NEW.created_at)::TEXT || '-' ||
        LPAD(NEW.customer_number::TEXT, 4, '0');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create customers table
CREATE TABLE public.customers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    customer_number SERIAL,  -- For generating customer ID like CUST-2024-0001
    customer_id TEXT,
    first_name TEXT,
    last_name TEXT,
    full_name TEXT GENERATED ALWAYS AS (
        COALESCE(first_name, '') || 
        CASE WHEN first_name IS NOT NULL AND last_name IS NOT NULL THEN ' ' ELSE '' END || 
        COALESCE(last_name, '')
    ) STORED,
    birthdate DATE,
    sex TEXT CHECK (sex IN ('Male', 'Female', NULL)),
    location TEXT,
    whatsapp_number TEXT,
    referral_source TEXT,  -- How did you hear about us?
    medical_conditions TEXT[],  -- Array of medical conditions
    interests TEXT[],  -- Array of interests
    profession TEXT,
    visit_reason TEXT,  -- Why are you visiting Vultun?
    email_newsletter BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Create trigger for customer_id generation
CREATE TRIGGER generate_customer_id_trigger
    BEFORE INSERT ON public.customers
    FOR EACH ROW
    EXECUTE FUNCTION generate_customer_id();

-- Create a view that includes the calculated age
CREATE OR REPLACE VIEW public.customer_details AS
SELECT 
    c.*,
    calculate_age(c.birthdate) as age
FROM public.customers c;

-- Create index for faster lookups
CREATE INDEX idx_customers_user_id ON public.customers(user_id);
CREATE INDEX idx_customers_customer_id ON public.customers(customer_id);
CREATE INDEX idx_customers_birthdate ON public.customers(birthdate);

-- Enable Row Level Security
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own customer data"
    ON public.customers
    FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Staff can view all customer data"
    ON public.customers
    FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.users
            WHERE id = auth.uid() AND role IN ('staff', 'admin')
        )
    );

CREATE POLICY "Admin can manage all customer data"
    ON public.customers
    USING (
        EXISTS (
            SELECT 1 FROM public.users
            WHERE id = auth.uid() AND role = 'admin'
        )
    );

-- Create trigger for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = TIMEZONE('utc'::text, NOW());
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_customers_updated_at
    BEFORE UPDATE ON public.customers
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column(); 