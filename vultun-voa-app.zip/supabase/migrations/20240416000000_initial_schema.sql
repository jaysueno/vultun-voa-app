-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create auth schema if it doesn't exist
CREATE SCHEMA IF NOT EXISTS auth;
CREATE SCHEMA IF NOT EXISTS extensions;

-- Drop existing views and tables if they exist
DROP TABLE IF EXISTS public.customers CASCADE;
DROP TABLE IF EXISTS public.users CASCADE;

-- Create customers table (consolidated from customers and customer_details)
CREATE TABLE customers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    customer_number SERIAL UNIQUE NOT NULL,
    first_name TEXT,
    last_name TEXT,
    full_name TEXT,
    email TEXT,
    birthdate DATE,
    sex TEXT,
    location TEXT,
    whatsapp_number TEXT,
    referral_source TEXT,
    medical_conditions TEXT[],
    interests TEXT[],
    profession TEXT,
    visit_reason TEXT,
    email_newsletter BOOLEAN DEFAULT false,
    age INTEGER,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now())
);

-- Update staff table to reference auth.users instead of public.users
ALTER TABLE staff 
    DROP CONSTRAINT IF EXISTS staff_user_id_fkey,
    DROP COLUMN IF EXISTS user_id,
    ADD COLUMN IF NOT EXISTS auth_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    ADD COLUMN IF NOT EXISTS first_name TEXT,
    ADD COLUMN IF NOT EXISTS last_name TEXT,
    ADD COLUMN IF NOT EXISTS email TEXT,
    ADD COLUMN IF NOT EXISTS bio TEXT,
    ADD COLUMN IF NOT EXISTS specialties TEXT[],
    ADD COLUMN IF NOT EXISTS schedule_preferences JSONB,
    ADD COLUMN IF NOT EXISTS commission_rate NUMERIC;

-- Enable Row Level Security
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE staff ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for customers
CREATE POLICY "Customers can view their own data"
    ON customers FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Customers can update their own data"
    ON customers FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Customers can insert their own data"
    ON customers FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Staff can view all customer data"
    ON customers FOR SELECT
    USING (EXISTS (
        SELECT 1 FROM staff WHERE auth_id = auth.uid()
    ));

CREATE POLICY "Staff can update customer data"
    ON customers FOR UPDATE
    USING (EXISTS (
        SELECT 1 FROM staff WHERE auth_id = auth.uid()
    ));

-- Create RLS policies for bookings
CREATE POLICY "Bookings access control"
    ON bookings FOR SELECT
    USING (
        auth.uid() IN (
            SELECT user_id FROM customers WHERE id = bookings.customer_id
            UNION
            SELECT auth_id FROM staff WHERE id = bookings.staff_id
        )
    );

CREATE POLICY "Bookings insert control"
    ON bookings FOR INSERT
    WITH CHECK (
        auth.uid() IN (
            SELECT user_id FROM customers WHERE id = bookings.customer_id
            UNION
            SELECT auth_id FROM staff WHERE id = bookings.staff_id
        )
    );

CREATE POLICY "Bookings update control"
    ON bookings FOR UPDATE
    USING (
        auth.uid() IN (
            SELECT user_id FROM customers WHERE id = bookings.customer_id
            UNION
            SELECT auth_id FROM staff WHERE id = bookings.staff_id
        )
    );

-- Create RLS policies for services
CREATE POLICY "Staff can manage services"
    ON services FOR ALL
    USING (EXISTS (
        SELECT 1 FROM staff WHERE auth_id = auth.uid()
    ));

-- Create RLS policies for memberships
CREATE POLICY "Memberships access control"
    ON memberships FOR ALL
    USING (
        auth.uid() = user_id OR
        EXISTS (SELECT 1 FROM staff WHERE auth_id = auth.uid())
    );

-- Create RLS policies for payments
CREATE POLICY "Payments access control"
    ON payments FOR ALL
    USING (
        auth.uid() = user_id OR
        EXISTS (SELECT 1 FROM staff WHERE auth_id = auth.uid())
    );

-- Drop existing triggers if they exist
DROP TRIGGER IF EXISTS update_customers_updated_at ON customers;
DROP TRIGGER IF EXISTS update_staff_updated_at ON staff;

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = timezone('utc'::text, now());
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers
CREATE TRIGGER update_customers_updated_at
    BEFORE UPDATE ON customers
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_staff_updated_at
    BEFORE UPDATE ON staff
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column(); 