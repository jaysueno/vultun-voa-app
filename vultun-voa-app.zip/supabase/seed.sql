-- Clear existing data in reverse dependency order
TRUNCATE calendar_events CASCADE;
TRUNCATE waitlist_entries CASCADE;
TRUNCATE bookings CASCADE;
TRUNCATE customers CASCADE;
TRUNCATE staff CASCADE;
TRUNCATE services CASCADE;
TRUNCATE rooms CASCADE;
TRUNCATE locations CASCADE;
TRUNCATE users CASCADE;

-- Insert test locations
INSERT INTO locations (id, name, address, city, state, zip, phone)
VALUES
  ('99999999-9999-9999-9999-999999999999', 'Main Studio', '123 Main St', 'Los Angeles', 'CA', '90001', '+1234567890');

-- Insert test services
INSERT INTO services (id, name, description, duration, price, capacity)
VALUES
  ('11111111-1111-1111-1111-111111111111', 'Reformer Pilates - Private', 'Private Pilates session on the reformer', 60, 75.00, 1),
  ('22222222-2222-2222-2222-222222222222', 'Pilates Mat Class', 'Group mat Pilates class', 45, 25.00, 8),
  ('33333333-3333-3333-3333-333333333333', 'Therapeutic Massage', 'Full body therapeutic massage', 60, 85.00, 1);

-- Insert test rooms
INSERT INTO rooms (id, location_id, name, capacity, equipment_type)
VALUES
  ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '99999999-9999-9999-9999-999999999999', 'Reformer Studio 1', 1, 'Reformer'),
  ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', '99999999-9999-9999-9999-999999999999', 'Mat Studio', 8, 'Mat'),
  ('cccccccc-cccc-cccc-cccc-cccccccccccc', '99999999-9999-9999-9999-999999999999', 'Massage Room 1', 1, 'Massage Table');

-- Insert users
INSERT INTO users (id, email, role, first_name, last_name, phone)
VALUES
  ('28f796c1-0976-4a83-a9a4-ffdc30ecde45', 'jay@vultun.com', 'admin', 'Jay', 'Admin', '+639123456789'),
  ('b5f37e7d-6e42-4c8b-9c25-78b5531b0123', 'staff1@vultun.com', 'staff', 'Staff', 'One', '+639123456790'),
  ('c6f48e8e-7f53-5d9c-0d36-89c6642c1234', 'staff2@vultun.com', 'staff', 'Staff', 'Two', '+639123456791'),
  ('d7f59f9f-8f64-6e0d-1e47-90d7753c2345', 'customer1@example.com', 'customer', 'Customer', 'One', '+639123456792'),
  ('e8f60f0f-9f75-7f1e-2f58-01e8864d3456', 'customer2@example.com', 'customer', 'Customer', 'Two', '+639123456793'),
  ('f9f71f1f-0f86-8f2f-3f69-12f9975e4567', 'customer3@example.com', 'customer', 'Customer', 'Three', '+639123456794');

-- Insert staff records
INSERT INTO staff (user_id, bio, specialties, commission_rate)
VALUES
  ('b5f37e7d-6e42-4c8b-9c25-78b5531b0123', 'Experienced Pilates instructor', ARRAY['Pilates', 'Yoga'], 0.60),
  ('c6f48e8e-7f53-5d9c-0d36-89c6642c1234', 'Licensed massage therapist', ARRAY['Massage', 'Physical Therapy'], 0.60);

-- Insert customer records
INSERT INTO customers (user_id, date_of_birth, emergency_contact, medical_conditions, preferences)
VALUES
  ('d7f59f9f-8f64-6e0d-1e47-90d7753c2345', '1990-01-01', 'Emergency Contact 1: +1234567890', ARRAY['None'], '{"preferred_instructor": "Staff One"}'),
  ('e8f60f0f-9f75-7f1e-2f58-01e8864d3456', '1985-05-15', 'Emergency Contact 2: +1234567891', ARRAY['None'], '{"preferred_time": "morning"}'),
  ('f9f71f1f-0f86-8f2f-3f69-12f9975e4567', '1995-12-31', 'Emergency Contact 3: +1234567892', ARRAY['None'], '{"preferred_service": "Pilates"}');

-- Create recurring bookings for the next 7 days
WITH RECURSIVE dates AS (
  SELECT CURRENT_DATE AS date
  UNION ALL
  SELECT date + 1
  FROM dates
  WHERE date < CURRENT_DATE + 7
)
INSERT INTO bookings (
  service_id,
  customer_id,
  staff_id,
  room_id,
  start_time,
  end_time,
  status,
  commission_rate
)
SELECT 
  '11111111-1111-1111-1111-111111111111'::uuid,
  (SELECT id FROM customers WHERE user_id = 'd7f59f9f-8f64-6e0d-1e47-90d7753c2345'),
  (SELECT id FROM staff WHERE user_id = 'b5f37e7d-6e42-4c8b-9c25-78b5531b0123'),
  'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'::uuid,
  date + TIME '10:00:00',
  date + TIME '11:00:00',
  'confirmed',
  0.60
FROM dates
WHERE EXTRACT(DOW FROM date) NOT IN (0, 6);  -- Weekdays only

-- Create calendar events for the bookings
INSERT INTO calendar_events (
  title,
  description,
  start_time,
  end_time,
  event_type,
  booking_id,
  room_id,
  staff_id
)
SELECT 
  'Private Pilates Session',
  'Regular session',
  start_time,
  end_time,
  'booking',
  id,
  room_id,
  staff_id
FROM bookings; 